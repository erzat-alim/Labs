﻿namespace Alimbeko_Erzat_DKIP_481_3LR
{
    partial class Alimbekov
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.buttonChars = new System.Windows.Forms.Button();
            this.labelChars = new System.Windows.Forms.Label();
            this.buttonLetter = new System.Windows.Forms.Button();
            this.labelLetter = new System.Windows.Forms.Label();
            this.buttonWords = new System.Windows.Forms.Button();
            this.labelWords = new System.Windows.Forms.Label();
            this.buttonStrings = new System.Windows.Forms.Button();
            this.labelStrings = new System.Windows.Forms.Label();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonReset = new System.Windows.Forms.Button();
            this.buttonSave = new System.Windows.Forms.Button();
            this.buttonOpen = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(14, 14);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(570, 310);
            this.textBox1.TabIndex = 0;
            // 
            // buttonChars
            // 
            this.buttonChars.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonChars.Location = new System.Drawing.Point(14, 331);
            this.buttonChars.Name = "buttonChars";
            this.buttonChars.Size = new System.Drawing.Size(184, 35);
            this.buttonChars.TabIndex = 1;
            this.buttonChars.Text = "Количество символов";
            this.buttonChars.UseVisualStyleBackColor = true;
            this.buttonChars.Click += new System.EventHandler(this.buttonChars_Click);
            // 
            // labelChars
            // 
            this.labelChars.AutoSize = true;
            this.labelChars.Location = new System.Drawing.Point(205, 339);
            this.labelChars.Name = "labelChars";
            this.labelChars.Size = new System.Drawing.Size(166, 18);
            this.labelChars.TabIndex = 2;
            this.labelChars.Text = "Количество символов";
            // 
            // buttonLetter
            // 
            this.buttonLetter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonLetter.Location = new System.Drawing.Point(14, 372);
            this.buttonLetter.Name = "buttonLetter";
            this.buttonLetter.Size = new System.Drawing.Size(184, 35);
            this.buttonLetter.TabIndex = 1;
            this.buttonLetter.Text = "Количество букв";
            this.buttonLetter.UseVisualStyleBackColor = true;
            // 
            // labelLetter
            // 
            this.labelLetter.AutoSize = true;
            this.labelLetter.Location = new System.Drawing.Point(205, 380);
            this.labelLetter.Name = "labelLetter";
            this.labelLetter.Size = new System.Drawing.Size(128, 18);
            this.labelLetter.TabIndex = 2;
            this.labelLetter.Text = "Количество букв";
            // 
            // buttonWords
            // 
            this.buttonWords.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonWords.Location = new System.Drawing.Point(14, 414);
            this.buttonWords.Name = "buttonWords";
            this.buttonWords.Size = new System.Drawing.Size(184, 35);
            this.buttonWords.TabIndex = 1;
            this.buttonWords.Text = "Количество слов";
            this.buttonWords.UseVisualStyleBackColor = true;
            // 
            // labelWords
            // 
            this.labelWords.AutoSize = true;
            this.labelWords.Location = new System.Drawing.Point(205, 422);
            this.labelWords.Name = "labelWords";
            this.labelWords.Size = new System.Drawing.Size(130, 18);
            this.labelWords.TabIndex = 2;
            this.labelWords.Text = "Количество слов";
            // 
            // buttonStrings
            // 
            this.buttonStrings.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonStrings.Location = new System.Drawing.Point(14, 456);
            this.buttonStrings.Name = "buttonStrings";
            this.buttonStrings.Size = new System.Drawing.Size(184, 35);
            this.buttonStrings.TabIndex = 1;
            this.buttonStrings.Text = "Количество строк";
            this.buttonStrings.UseVisualStyleBackColor = true;
            // 
            // labelStrings
            // 
            this.labelStrings.AutoSize = true;
            this.labelStrings.Location = new System.Drawing.Point(205, 464);
            this.labelStrings.Name = "labelStrings";
            this.labelStrings.Size = new System.Drawing.Size(136, 18);
            this.labelStrings.TabIndex = 2;
            this.labelStrings.Text = "Количество строк";
            // 
            // buttonClear
            // 
            this.buttonClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonClear.Location = new System.Drawing.Point(609, 14);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(120, 72);
            this.buttonClear.TabIndex = 3;
            this.buttonClear.Text = "C";
            this.buttonClear.UseVisualStyleBackColor = true;
            // 
            // buttonReset
            // 
            this.buttonReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonReset.Location = new System.Drawing.Point(609, 92);
            this.buttonReset.Name = "buttonReset";
            this.buttonReset.Size = new System.Drawing.Size(120, 72);
            this.buttonReset.TabIndex = 3;
            this.buttonReset.Text = "R";
            this.buttonReset.UseVisualStyleBackColor = true;
            // 
            // buttonSave
            // 
            this.buttonSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonSave.Location = new System.Drawing.Point(610, 217);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(119, 39);
            this.buttonSave.TabIndex = 4;
            this.buttonSave.Text = "Сохранить";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // buttonOpen
            // 
            this.buttonOpen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonOpen.Location = new System.Drawing.Point(609, 171);
            this.buttonOpen.Name = "buttonOpen";
            this.buttonOpen.Size = new System.Drawing.Size(119, 39);
            this.buttonOpen.TabIndex = 4;
            this.buttonOpen.Text = "Открыть";
            this.buttonOpen.UseVisualStyleBackColor = true;
            // 
            // Alimbekov
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(767, 506);
            this.Controls.Add(this.buttonOpen);
            this.Controls.Add(this.buttonSave);
            this.Controls.Add(this.buttonReset);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.labelStrings);
            this.Controls.Add(this.labelWords);
            this.Controls.Add(this.labelLetter);
            this.Controls.Add(this.labelChars);
            this.Controls.Add(this.buttonStrings);
            this.Controls.Add(this.buttonWords);
            this.Controls.Add(this.buttonLetter);
            this.Controls.Add(this.buttonChars);
            this.Controls.Add(this.textBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Name = "Alimbekov";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button buttonChars;
        private System.Windows.Forms.Label labelChars;
        private System.Windows.Forms.Button buttonLetter;
        private System.Windows.Forms.Label labelLetter;
        private System.Windows.Forms.Button buttonWords;
        private System.Windows.Forms.Label labelWords;
        private System.Windows.Forms.Button buttonStrings;
        private System.Windows.Forms.Label labelStrings;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonReset;
        private System.Windows.Forms.Button buttonSave;
        private System.Windows.Forms.Button buttonOpen;
    }
}

