﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Alimbeko_Erzat_DKIP_481_3LR
{
    public partial class Alimbekov : Form
    {
        public Alimbekov()
        {
            InitializeComponent();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {

        }

        private void buttonChars_Click(object sender, EventArgs e)
        {
            string txt = textBox1.Text;
            labelChars.Text = txt.Length.ToString();

        }
    }
}
